import time
import pandas as pd
import numpy as np
import statistics as stat

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }


   
def check_user_day_input(day):
    
    count_day = 0
    while(day != "Saturday" and day !="Sunday" and day != "Monday" and day !="Tuesday" and day != "Wednesday" and day!= "Thursday" and day != "Friday"):
                    
        day = input("Which day? Saturday, Sunday, Monday, Tuesday , Wednesday, Thursday and Friday As Written in Choices ")
        count_day +=1
                    
        if(count_day == 4):
            day = "all"
            break
        
    return day
    
def check_user_month_input(month):
    
    
    count_month = 0
    while(month != "January" and month != "February" and month != "March" and month != "April" and month != "May" and month != "June"):
        
        month = input("Which month? January, February, March, April, May or June? As Written in Choices or month will be set to all " )
        count_month +=1
                    
        if(count_month == 4):
            month = "all"
            break
    
    return month

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    
    print('Please enter your response as stated in the Question')
    
    response = ''
    
    flag = True
    
    
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    city = input("Would you like to see data for chicago , new york city or washington? ").lower()
    
    while flag:
        
        if city == 'chicago' or city == 'new york city' or city == 'washington':
        
            response = input("Would you like to filter the data by month , day , both ? Type 'all' for no time filter ").lower()
        
        
            # get user input for month and day
            if response == 'both':
                
                month = input("Which month? January, February, March, April, May or June? ")
                month = check_user_month_input(month)
                day = input("Which day? Saturday, Sunday, Monday, Tuesday , Wednesday, Thursday and Friday ") 
                day = check_user_day_input(day)
                flag = False
                
        
                    
            
            # get user input for month (all, january, february, ... , june)
            elif response == 'month':
                month = input("Which month? January, February, March, April, May or June? ")
                month = check_user_month_input(month)
                day = 'all'
                flag = False
                
            # get user input for day of week (all, monday, tuesday, ... sunday)
            elif response == 'day':
                day = input("Which day? Saturday, Sunday, Monday, Tuesday , Wednesday, Thursday and Friday ")
                day = check_user_day_input(day)
                month='all'
                flag = False
                
            #no filter is applied   
            elif response == 'all':
                month = "all"
                day = "all"
                flag = False
                
            else:
                response = input("Would you like to filter the data by month , day , both? Type 'all' for no time filter Hint As Written in choices ").lower()
                
                
           
        else:
            city = input("Would you like to see data for chicago , new york or washington? Hint As Written in Choices ").lower()
        

    
    print('-'*40)
    return city, month, day


def load_data(city, month, day ):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    # load data file into a dataframe
    df = pd.read_csv(CITY_DATA[city])
    
    
    
    # convert the Start Time column to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    
    #Create two new Columns ['Month' , 'Week Day']
    
    df['Month'] = df['Start Time'].dt.month
    df['day of week'] = df['Start Time'].dt.weekday_name


    
    # filter by month and day
    if month != 'all' and day != 'all':
        months = ['January', 'February', 'March', 'April', 'May' , 'June']
        month = months.index(month) + 1
        df = df[df['Month'] == month]
        df = df[df['day of week'] == day.title()]
        
    #filter by month 
    elif month!='all' and day == 'all':
        months = ['January', 'February', 'March', 'April', 'May' , 'June']
        month = months.index(month) + 1
        df = df[df['Month'] == month]
        
    #filter by day
    elif month == 'all' and day != 'all':
        df = df[df['Month'] < 7]
        df = df[df['day of week'] == day.title()]
    
    #No Filter applied
    elif month == 'all' and day == 'all':
        return df
        
    return df



def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    
    common_month = df['Month'].mode()[0]
    
    print("The most common month is " + str(common_month))
    
    # display the most common day of week

    common_day_of_week = df['day of week'].mode()[0]

    print("The most common day of week is " + str(common_day_of_week))
    
    
    
    # display the most common start hour
    
    df['Start Time'] = pd.to_datetime(df['Start Time'])

    df['hour'] = df['Start Time'].dt.hour

    common_hour = df['hour'].mode()[0]
    
    
    print("The most common start hour is " + str(common_hour))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station

    common_start_station = df['Start Station'].mode()[0]
    
    print("The most common start station is " + str(common_start_station))
    
    
    # display most commonly used end station
    
    common_end_station = df['End Station'].mode()[0]
    
    print("The most common end station is " + str(common_end_station))
    
    # display most frequent combination of start station and end station trip
    
    frequent_combination = df.groupby(['Start Station', 'End Station']).size().idxmax()
    
    print("The most most frequent combination of start station and end station trip is " + str(frequent_combination))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    
    total_travel_time = sum(df['Trip Duration'])
    
    print("Total travel time is " + str(total_travel_time))

    # display mean travel time
    
    mean_travel_time = stat.mean(df['Trip Duration'])
    
    print("Mean travel time is " + str(mean_travel_time))
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def user_stats_washington(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    
    user_types = df['User Type'].value_counts()
    
    print("The count of User Types is " + str(user_types))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    
    user_types = df['User Type'].value_counts()
    
    print("The count of User Types is " + str(user_types))
    
    # Display counts of gender
    
    if 'Gender' in df:
    # Only access Gender column in this case 
    
        gender = df['Gender'].value_counts()
        print("The count of gender is " + str(gender))
        
    else:
        
        print('Gender stats cannot be calculated because Gender does not appear in the dataframe')
    

    

    # Display earliest, most recent, and most common year of birth
    
    
    if 'Birth Year' in df:
    # Only access Gender column in this case 
    
        earliest_year_of_birth = max(year for year in df['Birth Year'] if year < 2021)
    
        recent_year_of_birth = df['Birth Year'].max()
    
        common_year_of_birth = df['Birth Year'].mode()[0]
    
    
        print("The Earliest year is " + str(earliest_year_of_birth))
    
        print("The most recent year is " + str(recent_year_of_birth))
    
        print("The most common year is " + str(common_year_of_birth))
        
    else:
        
        print('Birth Year stats cannot be calculated because Birth Year does not appear in the dataframe')
    
   

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)
    
        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break



if __name__ == "__main__":
	main()
